<?php global $pb_options;

$options = function_exists('cws_get_pb_options') ? cws_get_pb_options() : null;

?>
<!-- Text -->
<?php if (!$options || in_array('text', $options['modules']) ): ?>
<div id="cws-pb-text" style="display:none">
	<div class="row row_options">
		<label for="title">Widget Title:</label>
		<input type="text" name="title">
	</div>
	<div class="row">
		<div class="cws_tmce_buttons">
			<a href="#" id="insert-media-button" class="button insert-media add_media" title="Add Media"><span class="wp-media-buttons-icon"></span> Add Media</a>
			<div class="cws_tmce_controls">
				<a href="#" id="cws-switch-text" class="button" data-editor="content" data-mode="tmce" title="Switch to Text">Switch to Text</a>
			</div>
		</div>
		<div class="cws-pb-tmce">
			<textarea class="wp-editor-area" name="cws-pb-content" id="cws-pb-content"></textarea>
		</div>
	</div>
</div>
<?php endif; ?>
<!-- Tabs -->
<?php if (!$options || in_array('tabs', $options['modules']) ): ?>
<div id="cws-pb-tabs" style="display:none">
	<div class="row row_options">
		<label for="title">Tab Title:</label>
		<input type="text" name="title">
	</div>
	<div class="row">
		<div class="cws_tmce_buttons">
			<a href="#" id="insert-media-button" class="button insert-media add_media" title="Add Media"><span class="wp-media-buttons-icon"></span> Add Media</a>
			<div class="cws_tmce_controls">
				<a href="#" id="cws-switch-text" class="button" data-editor="content" data-mode="tmce" title="Switch to Text">Switch to Text</a>
			</div>
		</div>
		<div class="cws-pb-tmce">
			<textarea class="wp-editor-area" name="cws-pb-content" id="cws-pb-content"></textarea>
		</div>
	</div>
</div>
<?php endif; ?>

<!-- tweet -->
<?php if (!$options || in_array('tweet', $options['modules']) ): ?>
<div id="cws-pb-tweet" style="display:none">
	<div class="row row_options">
		<label for="title">Title:</label><input type="text" name="title"><br/>
		<!--
		<label for="p_render_t">Grid:</label><input name="p_render_t" type="radio" value="grid" checked />
		<label for="p_render_t">Carousel:</label><input name="p_render_t" type="radio" value="carousel" /><br/>
		-->
	</div>
	<div class="row row_options">
		<label for="p_visible">Tweets to show:</label><input type="text" name="p_visible" value="4"><br/>
	</div>
	<div class="row row_options">
		<label for="p_items">Tweets to extract:</label><input type="text" name="p_items" value="4"><br/>
	</div>
</div>
<?php endif; ?>
<!-- blog -->
<?php if ($options && in_array('blog', $options['modules']) ): ?>
<div id="cws-pb-blog" style="display:none">
	<div class="row row_options">
		<label for="title">Title:</label><input type="text" name="title">
	</div>
	<div class="row row_options">
		<label for="title">Select columns type:</label>
		<select placeholder="Select number of columns" data-placeholder="Select number of columns" name="p_cols">
			<option value="2">Two</option>
			<option value="3">Three</option>
			<option value="4">Four</option>
		</select>
	</div>
	<div class="row row_options">
		<label for="title">Select categories:</label>
		<select multiple placeholder="Select categories" data-placeholder="Select categories" name="p_cats">
		<?php echo cws_pb_print_taxonomy('category'); ?>
		</select>
	</div>
	<div class="row row_options">
		<label for="p_items">Items per page:</label><input type="text" name="p_items" value="8"><br/>
	</div>
</div>
<?php endif; ?>

<!-- portfolio -->
<?php if ($options && in_array('portfolio', $options['modules']) ): ?>
<div id="cws-pb-portfolio" style="display:none">
	<div class="row row_options">
		<label for="title">Title:</label><input type="text" name="title"><br/>
	</div>
	<div class="row row_options">
		<label for="p_cols">Select number of columns:</label>
		<select placeholder="Select number of columns" data-placeholder="Select number of columns" name="p_cols">
			<option value="1">One</option>
			<option value="2" selected>Two</option>
			<option value="3">Three</option>
			<option value="4">Four</option>
		</select>
	</div>
	<div class="row row_options">
		<label for="p_cats">Select categories:</label>
		<select multiple placeholder="Select categories" data-placeholder="Select categories" name="p_cats">
		<?php echo cws_pb_print_taxonomy('cws-portfolio-type'); ?>
		</select>
	</div>
	<div class="row row_options">
		<label for="p_filter">Use filter:</label><input name="p_filter" type="checkbox">
		<label for="p_carousel">Carousel:</label><input name="p_carousel" type="checkbox">
	</div>
	<div class="row row_options">
		<label for="p_items">Items per page:</label><input type="text" name="p_items"><br/>
	</div>
</div>
<?php endif; ?>

<!-- Ourteam -->
<?php if ($options && in_array('ourteam', $options['modules']) ): ?>
<div id="cws-pb-ourteam" style="display:none">
	<div class="row row_options">
		<label for="title">Title:</label><input type="text" name="title"><br/>
	</div>
	<div class="row row_options">
		<label for="p_render_o">Grid:</label><input name="p_render_o" type="radio" value="grid" checked />
		<label for="p_render_o">Carousel:</label><input name="p_render_o" type="radio" value="carousel"><br/>
	</div>
	<div class="row row_options">
		<label for="p_cats">Select categories</label>
		<select multiple placeholder="Select categories" data-placeholder="Select categories" name="p_cats">
		<?php echo cws_pb_print_taxonomy('cws-staff-dept'); ?>
		</select>
	</div>
</div>
<?php endif; ?>

<?php
function cws_pb_print_taxonomy($name) {
	$source = cws_pb_get_taxonomy_array($name);
	$output = '<option value=""></option>';
	foreach($source as $k=>$v) {
		$output .= '<option value="' . $k . '">' . $v . '</option>';
	}
	return $output;
}

function cws_pb_get_taxonomy_array($tax, $args = '') {
	if (!empty($args)) {
		$args .= '&';
	}
	$args .= 'hide_empty=0';
	$terms = get_terms($tax, $args);
	$ret = array();
	foreach ($terms as $k=>$v) {
		$ret[$v->slug] = $v->name;
	}
	return $ret;
}

?>

<!-- Callout -->
<?php if ($options && in_array('callout', $options['modules']) ): ?>
<div id="cws-pb-callout" style="display:none">
	<div class="row">
		<?php cws_pb_icon_selection();	?>
	</div>
	<div class="row row_options">
		<label for="title">Title:</label><input type="text" name="title">
	</div>
	<div class="row row_options">
		<label for="c_btn_text">Button text:</label><input type="text" name="c_btn_text">
	</div>
	<div class="row row_options">
		<label for="c_btn_href">Button Url:</label><input type="text" name="c_btn_href">
	</div>
	<br/>
	<div class="cws-pb-tmce">
		<textarea class="wp-editor-area" name="cws-pb-content" id="cws-pb-content"></textarea>
	</div>
</div>
<?php endif; ?>

<?php
	function cws_pb_icon_selection () {
		if (function_exists('cws_get_option')) {
			$font_array = cws_get_option( 'body-font' );
			$icon_img_size = $font_array['font-size'] * 1.14 * 1.5;
		} else {
			$icon_img_size = 48;
		}
		ob_start(); ?>
		<section class="icon-options">
			<div class="row">
			<ul class="redux-image-select">
			<li class="redux-image-select selected">
				<input name="fa" type="radio" value="fa"><i class="fa fa-flag fa-2x"></i>
			</li>
			<li class="redux-image-select">
				<input name="img" type="radio" value="img"><i class="fa fa-picture-o fa-2x"></i>
				</li>
			</ul>
			</div>
			<div class="row">
			<div class='image-part'>
				<div class="img-wrapper">
					<label for="cws-pb-icons"><?php  _e('Tab icon:', THEME_SLUG); ?></label>
					<select id="cws-pb-icons" placeholder="Pick an icon for this module" data-placeholder="Pick an icon for this module" name="">
						<?php
							echo cws_pb_print_fa_select(true);
						?>
					</select>
				</div>
				<div class="img-wrapper" style="display:none">
					<a id="pb-media-cws-pb"><?php _e('Click to select image', THEME_SLUG); ?></a>
					<a id="pb-remov-cws-pb" style="display:none"><?php _e('Remove this image', THEME_SLUG); ?></a>
					<input class="image" readonly id="" name="" type="hidden" value />
					<img width="<?php echo $icon_img_size; ?>" height="<?php echo $icon_img_size; ?>" id="img-cws-pb" src alt />
				</div>
			</div>
			</div>
		</section>
		<?php ob_end_flush();
	}
	function cws_pb_print_fa_select($all = false) {
		//require_once( get_template_directory() . '/framework/rc/inc/fields/select/fa-icons.php');
		$output = '<option value=""></option>';
		//$icons = $all ? get_all_fa_icons() : get_font_fa_icons();
		if (function_exists('get_all_fa_icons')) {
			$icons = get_all_fa_icons();
			foreach ($icons as $icon) {
				$output .= '<option value="' . $icon . '">' . $icon . '</option>';
			}
		}
		return $output;
	}
?>
<!-- Table columns -->
<?php if (!$options || in_array('tcol', $options['modules']) ): ?>
<div id="cws-pb-tcol" style="display:none">
	<div class="row row_options">
		<label for="title">Column Title:</label><input type="text" name="title">
	</div>
	<div class="row row_options">
		<label for="currency">Currency:</label><input type="text" name="currency">
	</div>
	<div class="row row_options">
		<label for="price">Price:</label><input type="text" name="price">
	</div>
	<div class="row row_options">
		<label for="price_description">Price description:</label><input type="text" name="price_description">
	</div>
	<div class="row row_options">
		<label for="encouragement">Encouragement:</label><input type="text" name="encouragement">
	</div>
	<div class="row row_options">
		<label for="order_url">Order url:</label><input type="text" name="order_url">
	</div>
	<div class="row row_options">
		<label for="button_text">Button text:</label><input type="text" name="button_text">
	</div>
	<div class="row row_options">
		<label for="ishilited">Highlighted:</label><input type="checkbox" name="ishilited">
	</div>
	<div class="row">
		<div class="cws_tmce_buttons">
			<a href="#" id="insert-media-button" class="button insert-media add_media" data-editor="content" title="Add Media"><span class="wp-media-buttons-icon"></span> Add Media</a>
			<div class="cws_tmce_controls">
				<a href="#" id="cws-switch-text" class="button" data-editor="content" data-mode="tmce" title="Switch to Text">Switch to Text</a>
			</div>
		</div>
		<div class="cws-pb-tmce">
			<textarea class="wp-editor-area" name="cws-pb-content" id="cws-pb-content"></textarea>
		</div>
	</div>
</div>
<?php endif; ?>
<!-- Accordions -->
<?php if (!$options || in_array('accs', $options['modules']) ): ?>
<div id="cws-pb-accs" style="display:none">
	<div class="row">
	<?php cws_pb_icon_selection(); ?>
	</div>
	<div class="row row_options">
		<label for="title">Accordion Title:</label><input type="text" name="title">
	</div>
	<div class="row">
		<div class="cws_tmce_buttons">
			<a href="#" id="insert-media-button" class="button insert-media add_media" title="Add Media"><span class="wp-media-buttons-icon"></span> Add Media</a>
			<div class="cws_tmce_controls">
				<a href="#" id="cws-switch-text" class="button" data-editor="content" data-mode="tmce" title="Switch to Text">Switch to Text</a>
			</div>
		</div>
			<div class="cws-pb-tmce">
				<textarea class="wp-editor-area" name="cws-pb-content" id="cws-pb-content"></textarea>
			</div>
	</div>
</div>
<?php endif; ?>

<!-- Row settings -->
<div id="cws-pb-accs-title" style="display:none">
	<div class="row row_options">
		<label for="title">Accordion Title:</label>
		<input type="text" name="title" />
	</div>
	<div class="row row_options">
		<label for="title">Use it as toggle?:</label>
		<input type="checkbox" name="istoggle" />
	</div>
</div>

<div id="cws-pb-col" style="display:none">
	<div class='row row_options'>
		<label for="margins">Margins:</label>
		<fieldset class='margins'>
			<input type="number" id="margin_left" name="margin_left" placeholder="Left (px)">
			<input type="number" id="margin_top" name="margin_top" placeholder="Top (px)">
			<input type="number" id="margin_bottom" name="margin_bottom" placeholder="Bottom (px)">
			<input type="number" id="margin_right" name="margin_right" placeholder="Right (px)">
		</fieldset>
	</div>
<?php
	if (is_array($pb_options['features']) && in_array('row-img', $pb_options['features'])):
?>
	<label for="cws-pb-row-img"><?php _e('Add background image', THEME_SLUG)?></label>
	<fieldset class='margins'>
		<a id="cws-pb-media-row-img"><?php _e('Add image', THEME_SLUG); ?></a>
		<a id="cws-pb-remove-row-img" style="display:none"><?php _e('Remove this image', THEME_SLUG); ?></a>
		<input class="widefat" hidden readonly id="cws-pb-row-img" name="cws-pb-row-img" type="text" value="" />
		<img id="cws-row-img" src />
	</fieldset>
<?php
	endif;
?>
<?php
		if ( function_exists( 'cws_pb_add_extra_styles' ) ) {
			$options = cws_pb_add_extra_styles();
			if (count($options)) {
			?>
				<div class="row row_options">
					<label for="extra_style">Extra style name:</label>
					<select name="extra_style" class="sel2">
						<?php
						foreach ($options as $k=>$v) {
							echo '<option value="' . $k . '">' . $v . '</option>';
						}
						?>
					</select>
				</div>
<?php
			}
		}
	?>
</div>
<div id="cws-pb-col-title" style="display:none">
	<form>
		<div class="row row_options">
			<label for="title">Widget Title:</label>
			<input type="text" name="title">
		</div>
		<div class="row row_options">
			<label for="extra_style">Extra style name:</label>
			<select name="extra_style_col">
				<option value="" selected>Default</option>
				<option value="type-2">Alternative</option>
				<option value="type-vertical">Vertical</option>
			</select>
		</div>
	</form>
</div>
<div id="pb_overlay" style="display:none"></div>
<div id="cws_content_wrap" data-cws-ajurl="<?php echo CWS_PB_PLUGIN_URL ?>" class="wp-editor-container" style="display:none">
	<div id="bd">
		<div class="yui-b elements_panel">
			<div id="feeds">
				<div class='tabs clearfix'>
					<a class='active' href="#" onclick="document.getElementById('feeds-modules').style.display = 'none';document.getElementById('feeds-cols').style.display = 'block';">Columns</a>
					<a href="#" onclick="document.getElementById('feeds-modules').style.display = 'block';document.getElementById('feeds-cols').style.display = 'none';">Modules</a>
				</div>
				<div class='tabs_content'>
					<ul id="feeds-cols" class='tab_section clearfix'></ul>
					<ul id="feeds-modules" class='tab_section clearfix' style="display:none"></ul>
				</div>
			</div>
		</div>
		<div id="yui-main">
			<div class="yui-b">
				<div class="yui-g">
					<ul id="cws_row"></ul>
				</div>
			</div>
		</div>
	</div>
</div>